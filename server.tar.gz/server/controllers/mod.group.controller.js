import express from 'express';
import query from './../querys/querys.js';
const {insertIntoAdminGroupModules, deleteFromAdminGroupModules, updateAdminGroupModule, selectAdminGroupModuleViaId, selectAdminGroupModuleViaKey} = query; 

async function insert(req, res)  {
    const {userId, primaryAuthor, moduleName, messageForumId, keyName, penName, joinedModuleId} = req.body;
    // ensure the try statement is necessary on insert by disabling database and attempting connection and insert or doing faulty insert.
    
    let result =  await insertIntoAdminGroupModules(userId, primaryAuthor, moduleName, messageForumId, keyName, penName, joinedModuleId);
    if (result.affectedRows > 0) {
    res.status(200).json({message: 'success'})
    } else {
        res.status(500).json({message: 'failed'});
    }
};
async function del(req, res)  {
    const {id} = req.body;
    let result =  await deleteFromAdminGroupModules(id);
    if (result.affectedRows > 0) {
    res.status(200).json({message: 'success'})
    } else {
        res.status(500).json({message: 'failed'});
    }

}
async function update(req, res)  {
    const {adminModuleId, moduleName, messageForumId, keyName, penName, joinedModuleId} = req.body;
    let result =  await updateAdminGroupModule(adminModuleId, moduleName, messageForumId, keyName, penName, joinedModuleId);
    if (result.affectedRows > 0) {
    res.status(200).json({message: 'success'})
    } else {
        res.status(500).json({message: 'failed'});
    }

}
async function select(req, res)  {
    const {id} = req.params;
    
    let result =  await selectAdminGroupModuleViaId(id);
    if(typeof result.length !== 'undefined' && result.length > 0) {
    res.status(200).json({result: result, message: 'successfull'});
    } else {
    res.status(404).json({message: 'Not found!'});
    }
}
async function selectViaKey(req, res)  {
    const {key} = req.params;
    
    let result =  await selectAdminGroupModuleViaKey(key);
    if(typeof result.length !== 'undefined' && result.length > 0) {
    res.status(200).json({result: result, message: 'successfull'});
    } else {
    res.status(404).json({message: 'Not found!'});
    }
}

export default {insert, del, update, select, selectViaKey};