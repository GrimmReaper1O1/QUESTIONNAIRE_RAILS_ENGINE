let fetchIt = async (option,  limit = '', letter = '',  searchInfo = '', offset = '' ) => {
  
   
   let baseUrl = 'http://localhost:5000/api/auth/questions/subject';
   const params = {id: sessionStorage.getItem('subjectId'), option: 'id'};

   console.log(params);
   
   let queryString = new URLSearchParams(params).toString();
   let apiURL = `${baseUrl}?${queryString}`;
   
   await fetch(apiURL).then(async res => {
       if (res.ok) {
           
           let response = await res.json();
           console.log(response);
           displayInfo(response.result[0]);
            sessionStorage.setItem('subjectObj', JSON.stringify(response.result[0]));
       } else {
           throw Error('It did not go through!');
       }
       
   }).catch(error => {
       console.log(error);
       
   });

};
var displayInfo = async (object) => {
        
    let obj2 = {}; 
        obj2 = {...object, ...{
            apendixArr: (typeof object.apendix === 'string' ? JSON.parse(object.apendix) : null),
            videoArr: (typeof object.videos === 'string' ? JSON.parse(object.videos) : null),
            linkObj: (typeof object.links === 'string' ? JSON.parse(object.links) : null),
        }};

        delete obj2.links, obj2.video, obj2.apendix;

        console.log(obj2);



        let showHelper = (obj) => {



            let el0, el1, el2, el3, el4, indexNu, temp0, temp1, br;
            el0 = document.getElementById('heading');
            el1 = document.getElementById('introductionOne');
            el2 = document.getElementById('links');
            el3 = document.getElementById('apendix');
            el4 = document.getElementById('videos');
            
            for (key in obj.apendixArr) {
                // to fill at a later time


            }

            for (key in obj.videoArr) {
                //to fill at a later time


            }


            for (key in obj.linkObj) {
                const fillLinks = (option, obj, key) => {
                    let temp0 = option;
                    console.log(option.length, key.length);
                    let position = key.length - ((key.length - option.length)) ;

                    indexNu =  key[(position)]+`${(typeof key[(Number(position)+1)] !== 'undefined' ? key[(Number(position)+1)] : '')}`;
               
                let element = document.createElement('h4')
                element.setAttribute('id', key);
                br = document.createElement('br');
                
                console.log(element);
                el2.append(element);
                document.getElementById(key).textContent = (option === 'link' ? `link ${indexNu}: ` :'description ')+ obj.linkObj[key];
                }

                if (key.includes('kDescription')) {
                 fillLinks('linkDescription', obj, key);
             } else {
                fillLinks('link', obj, key);
             }
                

            }
let el;
            for (key in obj) {

                if (key !== 'videoArr' && key !== 'apendixArr' && key !== 'linkObj') {
                    
                     el = document.getElementById(key);
                     console.log(el);
                     if (el !== null) {
                        console.log(el);
                        switch (key) {
                            case 'name':
                            el.innerHTML = obj[key];
                            break;
                            case 'introduction':
                            element = document.createElement('h2');
                            element.textContent = 'INTRODUCTION';
                            el.before(element);
                            el.append(obj[key]);
                            break;
                            default:

                            break;
                        }
                    }
                }

            }
            let buttonDiv = document.createElement('div');
            let studyButton = document.createElement('button');
            studyButton.textContent = 'STUDY QUESTIONNAIRE';
            studyButton.setAttribute('onclick', 'goToPage(event)');
            console.log(studyButton);
            buttonDiv.append(studyButton)
            el0.after(buttonDiv);
            
            }

showHelper(obj2);

// object extraction
        
    }



fetchIt();

let goToPage = (e)=>{ e.preventDefault(); sessionStorage.setItem('pNum', 1); location.href = 'learnFromSubjectTwo.html?reset=yes&resetTwo=yes'; }