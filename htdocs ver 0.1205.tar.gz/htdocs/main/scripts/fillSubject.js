runFirst = () => {
    let string = ''
    for (let i = 1; i < 11; i++) {
        string += `Page Link ${i} <br>`;
        string += `<input class="formGroup" type="text" id="link${i}"/><br>`;
        string += `Link Description <br>`;
        string += `<textarea class="formGroup" cols="20" rows="3" id="linkDescription${i}"></textarea><br>`;

    }
    let element = document.getElementById('numberOfRemoval');
    let div = document.createElement('div');
    div.innerHTML = string;
    element.after(div);
    console.log(div);

}
runFirst();


let collectInfo = (e) => {
    e.preventDefault();
    let objectArray = document.querySelectorAll('.formGroup');
    console.log(objectArray);
    let objectInfo = {};
    objectInfo.keys = [];
    for (i = 0; i < objectArray.length; i++) {
        if (objectArray[i].value !== '') {
            objectInfo[objectArray[i].id] = objectArray[i].value;
        } else {
            objectInfo[objectArray[i].id] = objectArray[i].textContent;
            
        }
        objectInfo.keys.push(objectArray[i].id);
    }
    let objectInfo2 = {};
    let completeObject = {};
    for(key in objectInfo) {
        console.log(key);
        if (key.includes('link')) {
            console.log(objectInfo[key]);
            objectInfo2[key] = objectInfo[key];
            
        } else {
            completeObject[key] = objectInfo[key];
        }
    }
    completeObject['link'] = JSON.stringify(objectInfo2);
    console.log(completeObject);
    completeObject.creator = localStorage.getItem('id');
    
    let options = {method: 'PUT', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(completeObject), 
    //credentials: 'include'
    // uncomment credentials for https httponly cookie 
    };
    
    let url = 'http://localhost:5000/api/auth/questions/subject';

    fetch(url, options).then(async req => {
        console.log(req);



        if (req.ok) {
            console.log('got here');
            let id = await req.json();
            console.log(id);
            sessionStorage.setItem('subjectId', id.insertId);
            location.href = '/main/insertQuestionId.html';
            
        } else {
            throw Error('The transmission did not go well.')
        }
        
        
    }).catch(error => {
        console.log(error);
    })
    
    
}