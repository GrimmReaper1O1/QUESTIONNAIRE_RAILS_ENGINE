
const resetScore = e => {
    let answerObj = JSON.parse(sessionStorage.getItem('answerObj'));
    answerObj.right = 0;
    answerObj.wrong = 0;
    answerObj.attempted = 0;
    for (key in answerObj.object.questionNumbers) {
        for (key2 in answerObj.object.questionNumbers[key]) {
            answerObj.object.questionNumbers[key2] = 0;
        }


    }

    saveToBrowser(answerObj, 'saveScore')
}